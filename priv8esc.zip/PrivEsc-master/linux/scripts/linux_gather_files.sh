#!/bin/bash

tar -zcf linux_files.tar.gz /etc/* /home/* /root/* /var/www/* /var/log/*
